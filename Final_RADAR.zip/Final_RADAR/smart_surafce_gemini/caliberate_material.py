# calibrate_material.py

import time
import statistics
from hw_layer import measure_distance, buzzer_beep

# --- CONFIGURATION ---
# More readings are good here to ensure we capture the variance caused by absorption.
READINGS_PER_OBJECT = 50

# --- DATA STORAGE ---
calibration_data = {
    "reflective": [],
    "absorbent": []
}

def run_calibration_test(material_type, instructions):
    """
    A guided function to take sensor readings for a specific material type.
    
    Args:
        material_type (str): The key for storing data (e.g., "reflective").
        instructions (str): The message to show the user.
    
    Returns:
        list: A list of all the standard deviation (sigma) values recorded.
    """
    print("\n" + "="*50)
    print(f"  CALIBRATION STEP: Testing a '{material_type.upper()}' Material")
    print("="*50)
    print(f"\n  Instructions: {instructions}")
    
    # IMPORTANT: Use a flat surface for all tests to isolate the material effect.
    print("  Please ensure the surface of the object is as FLAT as possible.")
    
    input("\n  >>> Press Enter when you are ready to begin the test...")
    
    print(f"\n  Taking {READINGS_PER_OBJECT} readings. Please keep the object still...")
    
    sigmas = []
    for i in range(READINGS_PER_OBJECT):
        avg_dist, sigma = measure_distance(samples=5)
        
        if avg_dist > 0:
            sigmas.append(sigma)
            
        print(f"  Reading {i+1}/{READINGS_PER_OBJECT} -> Distance: {avg_dist:.2f} cm, Sigma: {sigma:.2f}")
        time.sleep(0.1)
        
    buzzer_beep(0.2)
    print("\n  ...Test complete for this material.")
    return sigmas


def analyze_results(data):
    """
    Analyzes the collected data and suggests a new calibration threshold.
    """
    print("\n" + "#"*60)
    print("  MATERIAL CALIBRATION ANALYSIS & CONCLUSION")
    print("#"*60)
    
    if not data["reflective"] or not data["absorbent"]:
        print("\nERROR: Data for both 'reflective' and 'absorbent' materials must be")
        print("collected to generate a valid conclusion. Please run the script again.")
        return

    max_reflective_sigma = max(data["reflective"])
    min_absorbent_sigma = min(data["absorbent"])

    print(f"\n- REFLECTIVE materials (hard surfaces) produced sigmas up to: {max_reflective_sigma:.2f}.")
    print(f"- ABSORBENT materials (soft surfaces) produced sigmas starting from: {min_absorbent_sigma:.2f}.")

    if max_reflective_sigma >= min_absorbent_sigma:
        print("\nWARNING: The sigma values for your reflective and absorbent materials")
        print("overlap. This means the sensor may have difficulty telling them apart.")
        print("Try using a harder or smoother reflective material, or a softer")
        print("absorbent material to increase the difference.")
        # Suggest a threshold anyway, but with a warning
        threshold = round((max_reflective_sigma + min_absorbent_sigma) / 2, 2)
    else:
        # Suggest a threshold halfway between the two material types for a clear cutoff.
        threshold = round((max_reflective_sigma + min_absorbent_sigma) / 2, 2)

    # --- Generate the final conclusion ---
    print("\n" + "*"*60)
    print("  SUGGESTED CALIBRATION CODE")
    print("*"*60)
    print("\nBased on your tests, it is recommended to replace the")
    print("'analyze_absorption' function in your 'hw_layer.py' file with this code:\n")

    print("--- (Copy the code below) ------------------------------------")
    print("def analyze_absorption(sigma):")
    print(f"    # A sigma above {threshold} suggests sound is being absorbed.")
    print(f"    if sigma > {threshold}:")
    print(f"        return \"High\"  # High absorption")
    print(f"    else:")
    print(f"        return \"Low\"   # Low absorption (reflective)")

    print("----------------------------------------------------------\n")
    print("Note: The 'Medium' category can be added back if you test")
    print("semi-absorbent materials and define a second threshold.\n")


if __name__ == "__main__":
    # --- Initialize Buzzer for feedback ---
    try:
        from hw_layer import BUZZER_PIN
        print("Buzzer found.")
    except ImportError:
        print("Warning: Could not find BUZZER_PIN. Using fallback.")
        BUZZER_PIN = 18

    print("="*60)
    print("  Smart Surface Detector - MATERIAL CALIBRATION UTILITY")
    print("="*60)
    print("\nThis script will test different materials to find the ideal")
    print("threshold between 'Reflective' and 'Absorbent' surfaces.")
    
    # --- Run the tests ---
    calibration_data["reflective"] = run_calibration_test(
        "reflective",
        "Place a hard, FLAT object (wood, plastic, metal, or a thick book) about 20-30 cm away."
    )
    
    calibration_data["absorbent"] = run_calibration_test(
        "absorbent",
        "Place a soft, FLAT object (a sponge, thick towel, foam block, or carpet square) in the same position."
    )
    
    # --- Analyze and Conclude ---
    analyze_results(calibration_data)
