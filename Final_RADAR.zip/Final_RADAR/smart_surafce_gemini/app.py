# app.py

from flask import Flask, jsonify, render_template, request
# Note the simplified imports - we don't need to know the pin numbers here
from hw_layer import (measure_distance, analyze_absorption, read_color,
                      read_temperature, buzzer_beep, update_physical_oled) 
import threading
import statistics
import random

app = Flask(__name__)

def analyze_shape(sigma):
    if sigma < 0.5: return "Flat Surface"
    elif sigma < 2.5: return "Slightly Curved"
    else: return "Curved / Irregular"

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/scan', methods=['POST'])
def scan_route():
    data = request.get_json()
    repetitions = data.get('repetitions', 20)
    repetitions = min(int(repetitions), 100)
    
    distances = [measure_distance(samples=1)[0] for _ in range(repetitions)]
    # Filter out failed readings (which return 0)
    valid_distances = [d for d in distances if d > 0]
    
    if not valid_distances:
        return jsonify({"error": "Failed to get valid distance readings."}), 500

    scan_data = [{"reading": i + 1, "distance": dist} for i, dist in enumerate(valid_distances)]

    overall_sigma = round(statistics.stdev(valid_distances), 2) if len(valid_distances) > 1 else 0
    avg_distance = round(statistics.mean(valid_distances), 2)

    material_type = "Absorbing" if analyze_absorption(overall_sigma) == "High" else "Reflective"
    shape_result = analyze_shape(overall_sigma)
    
    temps = read_temperature()
    color = read_color()
    temp_diff = round(temps["object"] - temps["ambient"], 1)
    ultrasonic_speed = round(331.3 + 0.606 * temps["ambient"], 1)

    threading.Thread(
        target=update_physical_oled, 
        args=(f"{avg_distance} cm", shape_result, material_type)
    ).start()

    return jsonify({
        "scan_data": scan_data,
        "statistics": { "average": avg_distance, "sigma": overall_sigma },
        "shape_analysis": shape_result,
        "material_analysis": material_type,
        "environment": {
            "color": color["color_name"],
            "temp_difference": temp_diff,
            "ultrasonic_speed": ultrasonic_speed
        }
    })
    
@app.route('/measure_distance_single', methods=['POST'])
def measure_distance_single_route():
    avg, sigma = measure_distance(samples=10)
    threading.Thread(target=update_physical_oled, args=(f"{avg} cm", "N/A", "N/A")).start()
    return jsonify({ "distance": avg, "sigma": sigma })

@app.route('/buzzer', methods=['POST'])
def buzz_route():
    # The buzzer function no longer needs a pin number
    threading.Thread(target=buzzer_beep, args=(0.05,)).start()
    return jsonify({"status": "ok"})

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=5000, debug=False)